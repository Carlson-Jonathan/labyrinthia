import random,DialogBox,pygame,randMonster,combat,corridor1,grate,yell,savables
green,yellow = (0,225,0),(240,240,0)
gameDisplay = pygame.display.set_mode((900,600))
orange = (255,155,0)
red = (255,0,0)

def grate():
    #global health
    roll = random.randint(1,3)
    sewer = pygame.image.load('pictures\\rooms\\sewer.jpg')
    gameDisplay.blit(sewer,(250,0))
    if roll == 1:
        rungBreak()
    elif roll == 2:
        ladderPotion()
    elif roll == 3:
        monsterEncounter()
        
def sewerSelection(fromOption):
    choiceNum = (DialogBox.selectionx*DialogBox.selectiony)
    threeChoiceMenu = [sewerTravelOptions]
    if choiceNum == 3:
        ninjaTurtles() if fromOption == sewerTravelOptions else "" 
    elif choiceNum == 4:
        yell.yell() if fromOption == sewerTravelOptions else ""
    elif choiceNum == 5:
        choice = "do nothing."
    elif choiceNum == 6:
        invalid() if fromOption in threeChoiceMenu else ""
        fromOption()
    elif choiceNum == 8:
        invalid() if fromOption in threeChoiceMenu else ""
        fromOption()
    elif choiceNum == 10:
        invalid() if fromOption in threeChoiceMenu else ""
        fromOption()
        
def invalid():
    DialogBox.displayText("Invalid selection. Try again.",red,
    "",yellow,"",yellow,"",yellow,False,False)

def ninjaTurtles():
    DialogBox.displayText("You slosh down the sewer hoping to find",yellow,
    "a ladder up to a manhole or anything that",yellow,
    "might lead back the surface. You hear",yellow,
    "voices and the sound of something approaching.",yellow,False,False)
    turtles = pygame.image.load('pictures\\rooms\\ninjaTurtles.jpg')
    gameDisplay.blit(turtles,[250,0])
    DialogBox.displayText("                             ???,",yellow,
    "Who the heak are these... guys?",yellow,"",yellow,"",yellow,False,False)

def monsterEncounter():
    DialogBox.displayText("You reach the bottom with a splash and",yellow,
    "notice a pair of sinister yellow eyes slowly",yellow,
    "approaching you in the darkness.",yellow,"",yellow,False,False)
    randMonster.randMonster("weak","random")
    sewerTravelOptions()

def rungBreak():        
    trpDmg = random.randint (10,20)
    DialogBox.displayText("As you climb down the ladder one of the",yellow,
    "rungs breaks causing you to fall landing",yellow,
    "hard at bottom. You take %d damage to"%trpDmg,yellow,
    "your health.",yellow,False,False)
    savables.health -= trpDmg
    DialogBox.displayText("As you get back up you find yourself",yellow,
    "in a damp, wet sewer deep underground.",yellow,"",yellow,"",yellow,False,False)
    sewerTravelOptions()
    
def ladderPotion():
    DialogBox.displayText("On your way down the ladder you find",yellow,
    "a small bottle of red liquid strung over",yellow,
    "one of the center rungs. Without thinking",yellow,
    "you pop the cork and gulp it down.",yellow,False,False)
    DialogBox.displayText("It tastes like strawberries! Yummy!",yellow,
    "Your health increases by 30!",yellow,"",yellow,"",yellow,False,False)        
    savables.health += 30
    DialogBox.displayText("Well that was tasty! But now",yellow,
    "you are in a discusting looking sewer.",yellow,
    "Best not to drink anything else that might",yellow,
    "be randomly laying around down here.",yellow,False,False)
    sewerTravelOptions()
    
def sewerTravelOptions():
    DialogBox.displayText("What will you do?",yellow,
    "     Go down passage",orange,
    "     Yell for help",orange,
    "     Use item",orange,True,True)
    sewerSelection(sewerTravelOptions)
        