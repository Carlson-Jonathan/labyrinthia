import random,DialogBox,randMonster,combat,door,pygame,time,audio,savables
green,yellow,orange,red = (0,225,0),(240,240,0),(255,155,0),(255,0,0)
gameDisplay = pygame.display.set_mode((900,600))
clock = pygame.time.Clock()
riposte,parry = False,False
skillBar = 0
weaponAnimations = False

lightblue = (150,150,255)
greyout = 75,75,75
#swordTick,staffTick,fireTick,iceTick = 0,0,0,0

def fists():
    fistMin,fistMax = 4,12
    damage = random.randint(fistMin,fistMax)
    fisticuffs = ["slap","pinch","scratch","bite","kick","spit on","fart at","punch","mock","flick boogers at","give a wedgie to","trip"]
    action = random.choice(fisticuffs)
    audio.weaponSwoosh.play()
    DialogBox.displayText("You %s the %s!"%(action,randMonster.monster),yellow,
        "",yellow,"",yellow,"",yellow,False,False)
    audio.punch.play()
    DialogBox.displayText("You %s the %s!"%(action,randMonster.monster),yellow,
        "The %s takes %d damage"%(randMonster.monster,damage),orange,
        "to its health!",orange,"",yellow,False,False)
    combat.monsterHealth -= damage

def sword():
    global riposte,parry,skillBar,weaponAnimations
    savables.swordTick -= 2
    savables.swordTick = -56 if savables.swordTick <= -56 else savables.swordTick
    skillBar = savables.swordTick
    damage = random.randint(savables.swordMin,savables.swordMax)
    combat.monsterHealth -= damage
    DialogBox.displayText("You attack the %s with"%randMonster.monster,yellow,
        "your sword.",yellow,"",yellow,"",yellow,False,False)
    audio.weaponSwoosh.play()
    swordAnimation()
    weaponAnimations = True
    DialogBox.displayText("You attack the %s with"%randMonster.monster,yellow,
        "your sword.",yellow,"",yellow,"",yellow,False,False)
    weaponAnimations = False
    audio.monsterHit.play()
    monsterTakeDamage()
    DialogBox.displayText("You attack the %s with"%randMonster.monster,yellow,
    "your sword.",yellow,"The %s takes %d damage!"%(randMonster.monster,damage),orange,"",yellow,
    False,False)
    
def swordAnimation():
    swordPic = pygame.image.load('pictures\\weapons\\sword4.png')
    swX,swY,turn = 800,-350,-36
    while swY < 175 :
        clock.tick(75)
        swX += -20
        swY += 44
        turn += 8
        spin = pygame.transform.rotate(swordPic,(turn))
        gameDisplay.blit(spin,[swX,swY])
        redrawBorders()
        pygame.display.update()
        gameDisplay.blit(randMonster.monsterBackground,[250,0])
        gameDisplay.blit(randMonster.monsterPic,[250,0])
        
def redrawBorders():
    gameDisplay.blit(DialogBox.bottomBorder,[243,388])
    gameDisplay.blit(DialogBox.topBorder,[243,-3])
    gameDisplay.blit(DialogBox.leftBorder,[230,5])
    gameDisplay.blit(DialogBox.rightBorder,[880,5])
        
def monsterTakeDamage():
    blink = 0
    while blink < 9:
        clock.tick(35)
        gameDisplay.blit(randMonster.monsterBackground,[250,0])
        redrawBorders()
        pygame.display.update()
        gameDisplay.blit(randMonster.monsterPic,[250,0])
        redrawBorders()
        pygame.display.update()
        blink += 1
        
def parry():
    DialogBox.displayText("The %s attacks!"%randMonster.monster,yellow,
        "",green,"",yellow,"",yellow,False,False)
    audio.parryAttack.play()
    DialogBox.displayText("The %s attacks!"%randMonster.monster,yellow,
        "You parry the attack with your sword.",green,"",yellow,"",yellow,False,False)
def riposte():
    damage = random.randint(savables.swordMin,savables.swordMax)
    combat.monsterHealth -= damage
    combat.monsterBar = (((combat.monsterHealth*100)/combat.totalMhealth)*2)
    DialogBox.displayText("You riposte the %s's"%randMonster.monster,yellow,
    "attack with your sword!",yellow,"",yellow,"",yellow,False,False)
    audio.monsterHit.play()
    monsterTakeDamage()
    DialogBox.displayText("You riposte the %s's"%randMonster.monster,yellow,
    "attack with your sword!",yellow,
    "The %s takes %d damage!"%(randMonster.monster,damage),orange,"",yellow,False,False)
    if combat.monsterHealth <= 0:
        DialogBox.displayText("The %s drops to the ground"%randMonster.monster,yellow,
            "writhing and squealing!",yellow,"You are victorious!",yellow,
            "",yellow,False,False)
        combat.battle = False

def fire():
    global skillBar,weaponAnimations
    savables.fireTick -= 2
    savables.fireTick = -56 if savables.fireTick <= -56 else savables.fireTick
    skillBar = savables.fireTick    
    damage = random.randint(savables.fireMin,savables.fireMax)
    roll = random.randint(1,3)
    DialogBox.displayText("You shoot fire forth from your hands...",yellow,
        "",orange,"",yellow,"",yellow,False,False)
    audio.inferno.play()
    fireAnimation()
    audio.monsterHit.play()
    monsterTakeDamage()
    fireDamageText()
    combat.monsterHealth -= damage
    if roll == 3 and DialogBox.skill >= 1:
        damage = random.randint (10,(savables.fireMax/2))
        audio.fireBurn.play()
        DialogBox.displayText("The %s ignites on fire!"%randMonster.monster,yellow,
        "",yellow,"",yellow,"",yellow,False,False)
        monsterTakeDamage()
        DialogBox.displayText("The %s ignites on fire!"%randMonster.monster,yellow,
        "The %s takes %d more!"%(randMonster.monster,damage),orange,
        "damage!",orange,"",yellow,False,False)
        combat.monsterHealth -= damage
        audio.fireBurn.fadeout(1000)
        
def fireAttackText():
    damage = random.randint(savables.fireMin,savables.fireMax)
    DialogBox.displayText("You shoot fire forth from your hands...",yellow,
    "",orange,"",yellow,"",yellow,False,False)
    
def fireDamageText():
    damage = random.randint(savables.fireMin,savables.fireMax)
    DialogBox.displayText("You shoot fire forth from your hands...",yellow,
    "The %s takes %d damage!"%(randMonster.monster,damage),orange,
    "",yellow,"",yellow,False,False)
        
def fireAnimation():
    global weaponAnimations
    firePic = pygame.image.load('pictures\\weapons\\fireAttack.png')
    blitX,blitY,growX,growY,turn,accelerateX,accelerateY = 575,200,0,0,0,0,0
    while blitY > -900 :
        weaponAnimations = True
        clock.tick(50)
        blitX -= (accelerateX/2)
        blitY -= (accelerateY/2)
        growX += accelerateX
        growY += accelerateY
        accelerateX += 16
        accelerateY += 16
        turn += 90
        spin = pygame.transform.rotate(firePic,(turn))
        blast = pygame.transform.scale(spin,[growX,growY])
        gameDisplay.blit(blast,[blitX,blitY])
        redrawBorders()
        fireAttackText()
        pygame.display.update()
        gameDisplay.blit(randMonster.monsterBackground,[250,0])
        gameDisplay.blit(randMonster.monsterPic,[250,0])
    weaponAnimations = False
    
def ice():
    global skillBar
    savables.iceTick -= 2
    savables.iceTick = -56 if savables.iceTick <= -56 else savables.iceTick
    skillBar = savables.iceTick
    
    #deep freeze = skip enemy turn 
    #frost bite = reduce enemy damage
    #shatter armor = increase your damage
    
    freezeOnly = ("     Deep Freze                ?")
    freezeFrost = ("     Deep Freze                Frost Bite")
    none1 = ("     ?                                ?")
    none2 = ("     ?")
    Shatter = ("     Shatter Armor") 
    if DialogBox.skill == 0:
        row1 = none1
        row2 = none2    
    elif DialogBox.skill == 1:
        row1 = freezeOnly
        row2 = none2
    elif DialogBox.skill == 2:
        row1 = freezeFrost
        row2 = none2
    elif DialogBox.skill == 3:
        row1 = freezeFrost
        row2 = Shatter
    DialogBox.displayText("Select your type of ice attack:",yellow,
    "     Icebolt",lightblue,row1,lightblue,row2,lightblue,True,True)
    
def staff():
    global skillBar,weaponAnimations
    savables.staffTick -= 2
    savables.staffTick = -56 if savables.staffTick <= -56 else savables.staffTick
    skillBar = savables.staffTick
    min,max = savables.staffMin,savables.staffMax
    damage1,damage2,damage3,damage4,damage5 = random.randint(min,max),random.randint(min,max),random.randint(min,max),random.randint(min,max),random.randint(min,max)
    multiStrike = random.randint(-10,38) #34,27,18 = chance combos
    if multiStrike >= 34 and DialogBox.skill >= 3:
        DialogBox.displayText("You unleash a devestating flurry of blows!",yellow,
            "",yellow,"",yellow,"",yellow,False,False)
        DialogBox.displayText("You unleash a devestating flurry of blows!",yellow,
            "",yellow,"             S U P E R  C O M B O ! ! !",orange,"",yellow,False,False)
        audio.weaponSwoosh.play()
        staffMultiAni(585)
        weaponAnimations = True
        audio.monsterHit.play()
        DialogBox.displayText("You unleash a devestating flurry of blows!",yellow,
            "   You do %d damage!"%damage1,yellow,"",yellow,"",yellow,False,False)
        monsterTakeDamage()
        audio.monsterHit.play()
        DialogBox.displayText("You unleash a devestating flurry of blows!",yellow,
            "   You do %d damage!  You do %d damage!"%(damage1,damage2),yellow,"",yellow,"",yellow,False,False)
        monsterTakeDamage()
        audio.monsterHit.play()
        DialogBox.displayText("You unleash a devestating flurry of blows!",yellow,
            "   You do %d damage!  You do %d damage!"%(damage1,damage2),yellow,
            "   You do %d damage!"%damage3,orange,"",yellow,False,False)
        monsterTakeDamage()
        audio.monsterHit.play()
        DialogBox.displayText("You unleash a devestating flurry of blows!",yellow,
            "   You do %d damage!  You do %d damage!"%(damage1,damage2),yellow,
            "   You do %d damage!  You do %d damage!"%(damage3,damage4),orange,"",yellow,False,False)
        monsterTakeDamage()
        audio.monsterHit.play()
        DialogBox.displayText("You unleash a devestating flurry of blows!",yellow,
            "   You do %d damage!  You do %d damage!"%(damage1,damage2),yellow,
            "   You do %d damage!  You do %d damage!"%(damage3,damage4),orange,
            "                You do %d damage!"%damage5,red,False,False)
        monsterTakeDamage()
        weaponAnimations = False
        DialogBox.displayText("You unleash a devestating flurry of blows!",yellow,
            "   You do %d damage!  You do %d damage!"%(damage1,damage2),yellow,
            "   You do %d damage!  You do %d damage!"%(damage3,damage4),orange,
            "                You do %d damage!"%damage5,red,False,False)
        combat.monsterHealth -= (damage1+damage2+damage3+damage4+damage5)
        
    elif multiStrike >= 27 and DialogBox.skill >= 2:
        DialogBox.displayText("               T r i p l e  S t r i k e !",yellow,
            "",yellow,"",yellow,"",yellow,False,False)
        audio.weaponSwoosh.play()
        staffMultiAni(345)
        audio.monsterHit.play()
        weaponAnimations = True
        monsterTakeDamage()
        DialogBox.displayText("               T r i p l e  S t r i k e !",yellow,
            "The %s takes %d damage!"%(randMonster.monster,damage1),orange,
            "",yellow,"",yellow,False,False)
        audio.monsterHit.play()
        monsterTakeDamage()
        DialogBox.displayText("               T r i p l e  S t r i k e !",yellow,
            "The %s takes %d damage!"%(randMonster.monster,damage1),orange,
            "The %s takes %d damage!"%(randMonster.monster,damage2),red,
            "",yellow,False,False)
        audio.monsterHit.play()
        monsterTakeDamage()
        weaponAnimations = False
        DialogBox.displayText("               T r i p l e  S t r i k e !",yellow,
            "The %s takes %d damage!"%(randMonster.monster,damage1),orange,
            "The %s takes %d damage!"%(randMonster.monster,damage2),red,
            "The %s takes %d damage!"%(randMonster.monster,damage3),yellow,False,False)
        combat.monsterHealth -= (damage1+damage2+damage3)
    elif multiStrike >= 18 and DialogBox.skill >= 1:
        DialogBox.displayText("                     Double Strike!",yellow,"",yellow,"",yellow,"",yellow,False,False)
        audio.weaponSwoosh.play()
        staffAnimationRight()
        audio.weaponSwoosh.play()
        staffAnimationLeft()
        audio.monsterHit.play()
        monsterTakeDamage()
        audio.monsterHit.play()
        monsterTakeDamage()
        DialogBox.displayText("                     Double Strike!",yellow,
            "The %s takes %d damage!"%(randMonster.monster,damage1),orange,
            "The %s takes %d damage!"%(randMonster.monster,damage2),red,"",yellow,False,False)
        combat.monsterHealth -= (damage1+damage2)
    else:
        DialogBox.displayText("You strike the %s with"%randMonster.monster,yellow,
            "your staff!",yellow,"",yellow,"",yellow,False,False)
        audio.weaponSwoosh.play()
        roll = random.randint(1,2)
        staffAnimationLeft() if roll == 1 else staffAnimationRight()        
        audio.monsterHit.play()
        monsterTakeDamage()
        staffDamageText()
        combat.monsterHealth -= damage1
        
def staffStrikeText():
    min,max = savables.staffMin,savables.staffMax
    damage1 = random.randint(min,max)
    DialogBox.displayText("You strike the %s with"%randMonster.monster,yellow,
    "your staff!",yellow,"",yellow,"",yellow,False,False)
    
def staffDamageText():
    damage1 = random.randint(10,20)
    DialogBox.displayText("You strike the %s with"%randMonster.monster,yellow,
    "your staff!",yellow,
    "The %s takes %d damage!"%(randMonster.monster,damage1),orange,"",yellow,False,False)
        
def swooshCombo(number):
    hits = 0
    while hits < number:
        audio.weaponSwoosh.play()
        time.sleep(.15)
        hits += 1

def staffAnimationRight():
    global weaponAnimations
    staffPic = pygame.image.load('pictures\\weapons\\staffAni.png')
    stX,stY,turn = 750,-350,-36
    while stY < 175 :
        weaponAnimations = True
        clock.tick(75)
        stX += -30
        stY += 66
        turn += 9
        spin = pygame.transform.rotate(staffPic,(turn))
        gameDisplay.blit(spin,[stX,stY])
        redrawBorders()
        staffStrikeText()
        pygame.display.update()
        gameDisplay.blit(randMonster.monsterBackground,[250,0])
        gameDisplay.blit(randMonster.monsterPic,[250,0]) 
    weaponAnimations = False

def staffAnimationLeft():
    global weaponAnimations
    staffPic = pygame.image.load('pictures\\weapons\\staffAni2.png')
    stX,stY,turn = -25,-350,36
    while stY < 175 :
        weaponAnimations = True
        clock.tick(75)
        stX += 25
        stY += 55
        turn += -8
        spin = pygame.transform.rotate(staffPic,(turn))
        gameDisplay.blit(spin,[stX,stY])
        redrawBorders()
        staffStrikeText()
        pygame.display.update()
        gameDisplay.blit(randMonster.monsterBackground,[250,0])
        gameDisplay.blit(randMonster.monsterPic,[250,0])
    weaponAnimations = False
    
def staffMultiAni(hits):
    global weaponAnimations
    staffPic = pygame.image.load('pictures\\weapons\\staffMulti.png')
    turn = 0
    while turn < hits:
        weaponAnimations = True
        clock.tick(75)
        turn += 15
        spin = pygame.transform.rotate(staffPic,(turn))
        gameDisplay.blit(spin,[200,175])
        audio.weaponSwoosh.play() if turn%120 == 0 else ""
        redrawBorders()
        staffStrikeText()
        pygame.display.update()
        gameDisplay.blit(randMonster.monsterBackground,[250,0])
        gameDisplay.blit(randMonster.monsterPic,[250,0])
    weaponAnimations = False
        
    
        
