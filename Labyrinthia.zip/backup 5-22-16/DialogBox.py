import pygame,sys,time,savables,audio
from pygame.locals import *
pygame.mixer.pre_init(44100, -16, 1, 512) #<-- fixes sound lag delay :D
pygame.init()

# basic variable definitions
white = (255,255,255)
red = (255,0,0)
darkred = (125,0,0)
green = (0,225,0)
darkgreen = (0,100,0)
black = (0,0,0)
blue = (0,0,75)
yellow = (240,240,0)
orange = (255,155,0)
darkyellow = (210,210,0)
selectionx,selectiony = 1,1
skill = 0
HBwarning = False

# pygame initialization
pygame.init()
gameDisplay = pygame.display.set_mode((900,600))
swordIcon = pygame.image.load('pictures\\weapons\\sword2.jpg')
fist = pygame.image.load('pictures\\weapons\\fist.png')
staff = pygame.image.load('pictures\\weapons\\staff3.jpg')
fire = pygame.image.load('pictures\\weapons\\fire.jpg')
gun = pygame.image.load('pictures\\weapons\\minigun2.jpg')
star1 = pygame.image.load('pictures\\star2.png')
star2 = pygame.image.load('pictures\\star.png')
ice = pygame.image.load('pictures\\weapons\\ice.png')
Background1 = pygame.image.load('pictures\\background1.bmp').convert_alpha()
Background2 = pygame.image.load('pictures\\background2.bmp')
arrowCover1 = pygame.image.load('pictures\\arrowCover3.bmp')
arrowCover2 = pygame.image.load('pictures\\arrowCover4.bmp')
leftBorder = pygame.image.load('pictures\\leftBorder.png')
bottomBorder = pygame.image.load('pictures\\bottomBorder.png')
rightBorder = pygame.image.load('pictures\\rightBorder.png')
topBorder = pygame.image.load('pictures\\topBorder.png')
hPotion = pygame.image.load('pictures\\items\\health_potion.gif')
rPotion = pygame.image.load('pictures\\items\\whitePotion.jpg')
cursor = pygame.image.load('pictures\\cursor.png')
smallBox = pygame.image.load('pictures\\smallBorder.png')

font = pygame.font.SysFont("comicsansms",30)
font2 = pygame.font.SysFont("comicsansms",16)
font3 = pygame.font.SysFont("comicsansms",22)
clock = pygame.time.Clock()
undefined = font.render("?",True,yellow)
maxHealth = 100

def skillDisplayChange(equip):
    global skill
    if equip == "fists":
        skill = savables.fistSkill
    elif equip == "sword":
        skill = savables.swordSkill
    elif equip == "staff":
        skill = savables.staffSkill
    elif equip == "fire":
        skill = savables.fireSkill
    elif equip == "ice":
        skill = savables.iceSkill
    elif equip == "gun":
        skill = savables.gunSkill

# basic text/dialog display - if arrowX and arrowY == TRUE, selections apply 
def displayText(msg1,color1,msg2,color2,msg3,color3,msg4,color4,arrowX,arrowY):
    import randMonster,combat,weapons
    global selectionx,selectiony,maxHealth,HBwarning
    combat.damageDisplay()
    script = True
    tick = 1
    while script == True:
        clock.tick(35)
        if weapons.weaponAnimations == False:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:# or pygame.K_KP_ENTER:
                        audio.textForward.play()
                        script = False
                        
                # must include 'X' click game quit function for every 
                # 'while' loop or 'X' Windows button wont work while in loop
                if event.type == QUIT:
                        pygame.quit()
                        sys.exit()
        else:
            script = False
        
        # blue rectangle menu background and yellow outlines
        gameDisplay.blit(Background2,[0,0])
        gameDisplay.blit(Background1,(250,400))
        pygame.draw.rect(gameDisplay,yellow,(255,410,635,180),2)
        pygame.draw.rect(gameDisplay,yellow,(10,10,230,580),2)
        
        # Scene decorative borders
        gameDisplay.blit(bottomBorder,[243,388])
        gameDisplay.blit(topBorder,[243,-3])
        gameDisplay.blit(leftBorder,[230,5])
        gameDisplay.blit(rightBorder,[880,5])
        
        # menu titles and content
        weptitle = font3.render("Weapon",True,green)
        armor = font3.render("Armor",True,green)
        item = font3.render("Item",True,green)
        hlthtitle = font3.render("Health",True,green)
        gameDisplay.blit(weptitle,[85,17])
        gameDisplay.blit(armor,[93,140])
        gameDisplay.blit(item,[100,263])
        gameDisplay.blit(hlthtitle,[90,400])
        
        # Skill Bar
        import weapons
        if weapons.skillBar <= -56: 
            skillColor = darkyellow 
        else: 
            skillColor = green
        pygame.draw.rect(gameDisplay,skillColor,(90,113,15,(weapons.skillBar)))
        
        # Potion Item Boxes (keep behind borders)
        gameDisplay.blit(hPotion,[27,302]) if "potion" in savables.healthPotions else gameDisplay.blit(undefined,[49,307])
        gameDisplay.blit(rPotion,[97,302]) if "regenPotion" in savables.regenPotions else gameDisplay.blit(undefined,[119,307])
        
        if combat.equip == "sword":
            gameDisplay.blit(swordIcon,(26,56,))
        elif combat.equip == "fists":
            gameDisplay.blit(fist,(26,56))
        elif combat.equip == "staff":
            gameDisplay.blit(staff,(26,56))
        elif combat.equip == "fire":
            gameDisplay.blit(fire,(26,56))
        elif combat.equip == "gun":
            gameDisplay.blit(gun,(26,56))
        elif combat.equip == "ice":
            gameDisplay.blit(ice,(26,56))
        else: 
            gameDisplay.blit(undefined,[49,62])
        
        # Number of potions display
        numHpotions = str(len(savables.healthPotions))
        numHpotionsDisp = font3.render(numHpotions,True,green)
        gameDisplay.blit(numHpotionsDisp,[68,328]) if len(savables.healthPotions) > 0 else ""
        numRpotions = str(len(savables.regenPotions))
        numRpotionsDisp = font3.render(numRpotions,True,green)
        gameDisplay.blit(numRpotionsDisp,[138,328]) if len(savables.regenPotions) > 0 else ""
        
        #Weapon and Armor outlines
        gameDisplay.blit(smallBox,[25,55])
        gameDisplay.blit(smallBox,[25,175])
        
        # Potions Outlines
        gameDisplay.blit(smallBox,[25,300])
        gameDisplay.blit(smallBox,[95,300])
        gameDisplay.blit(smallBox,[165,300])
        
        skillDisplayChange(combat.equip)
        gameDisplay.blit(star2,(115,50)) if skill >= 1 else gameDisplay.blit(star1,(115,50))
        gameDisplay.blit(star2,(155,50)) if skill >= 2 else gameDisplay.blit(star1,(155,50))
        gameDisplay.blit(star2,(195,50)) if skill >= 3 else gameDisplay.blit(star1,(195,50))
        wDamage = font2.render("Damage:",True,orange)
        gameDisplay.blit(wDamage,[135,77])
        wDamage = font2.render(combat.dispDamage,True,orange)
        gameDisplay.blit(wDamage,[138,97])
  
        # Hero health amount display
        from savables import health
        health = 0 if health < 0 else health
        maxHealth = 100+(savables.healthTanks*100)
        health = maxHealth if health > maxHealth else health
        pygame.draw.rect(gameDisplay,darkred,(25,435,((float(health)/maxHealth)*200.0),45))
        hlthamt = font.render(("%s"%health),True,yellow) 
        pygame.draw.rect(gameDisplay,yellow,(25,435,200,45),2)
        gameDisplay.blit(hlthamt,[100,435])
        
        # Low health audio warning
        if savables.health <= 20 and HBwarning == False:
            HBwarning = True
            audio.heartBeat.play()
        elif savables.health > 20:
            HBwarning = False 
        
        # Monster health amount display
        if combat.battle == True:
            import combat
            mhlthtitle = font3.render(randMonster.monster,True,green)
            gameDisplay.blit(mhlthtitle,[25,495])
            combat.monsterBar = 0 if combat.monsterBar <= 0 else combat.monsterBar
            pygame.draw.rect(gameDisplay,darkred,(25,530,(combat.monsterBar),45))
            pygame.draw.rect(gameDisplay,yellow,(25,530,200,45),2)
        
        # dialog/text box engine
        textLine1 = font.render(msg1,True,color1)
        textLine2 = font.render(msg2,True,color2)
        textLine3 = font.render(msg3,True,color3)
        textLine4 = font.render(msg4,True,color4)
        gameDisplay.blit(textLine1,[275,415])
        gameDisplay.blit(textLine2,[275,455])
        gameDisplay.blit(textLine3,[275,495])
        gameDisplay.blit(textLine4,[275,535])
        pygame.display.update()
        
        # double column arrow selection menu
        while arrowX == True and arrowY == True:
            clock.tick(35)
            pygame.draw.rect(gameDisplay,yellow,(255,410,635,180),2)
            gameDisplay.blit(arrowCover1,[257,469])
            gameDisplay.blit(arrowCover2,[557,469])
            if selectionx <= 3 and selectiony <= 1:
                selectionx = 3
                selectiony = 1
                gameDisplay.blit(cursor,[265,470])
            elif selectionx == 4 and selectiony <= 1:
                selectiony = 1
                gameDisplay.blit(cursor,[265,510])
            elif selectionx >= 5 and selectiony <= 1:
                selectionx = 5
                selectiony = 1
                gameDisplay.blit(cursor,[265,550])
            elif selectionx <= 3 and selectiony >= 2:
                selectionx = 3
                selectiony = 2
                gameDisplay.blit(cursor,[565,470])
            elif selectionx == 4 and selectiony >= 2:
                selectiony = 2
                gameDisplay.blit(cursor,[565,510])
            elif selectionx >= 5 and selectiony >= 2:
                selectionx = 5
                selectiony = 2
                gameDisplay.blit(cursor,[565,550])
            for event in pygame.event.get():
                if event.type == QUIT:
                        pygame.quit()
                        sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        audio.selectTick.play()
                        arrowX = False
                        arrowY = False
                        script = False
                    elif event.key == pygame.K_DOWN:
                        audio.arrowTick.play()
                        selectionx += 1
                    elif event.key == pygame.K_UP:
                        audio.arrowTick.play()
                        selectionx -= 1
                    elif event.key == pygame.K_RIGHT:
                        audio.arrowTick.play()
                        selectiony += 1
                    elif event.key == pygame.K_LEFT: 
                        audio.arrowTick.play()
                        selectiony -= 1
            pygame.display.update()
 
