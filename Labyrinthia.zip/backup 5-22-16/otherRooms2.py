import pygame,DialogBox,audio,combat,savables,random
gameDisplay = pygame.display.set_mode((900,600))
yellow,green,orange,red = (240,240,0),(0,255,0),(255,155,0),(255,0,0)

'''
Module Contents:
    Fossil
'''    

darkFossil = pygame.image.load('pictures\\rooms\\fossilDark.jpg')
lightFossil = pygame.image.load('pictures\\rooms\\fossil.jpg')
matches = pygame.image.load('pictures\\items\\matches.png')
def fossil():
    gameDisplay.blit(darkFossil,[250,0])
    DialogBox.displayText("You continue on your way down the tunnel",yellow,
    "then see something inscribed on the wall.",yellow,
    "You feel that this is important somehow.",yellow,
    "Unfortunately you cant tell what it is.",yellow,False,False)
    DialogBox.displayText("You run your hand over it trying to guess",yellow,
    "what is could be. Writing? A picture?",yellow,
    "It is too dark and hard to make out.",yellow,
    "You pull out a match and light it.",yellow,False,False)
    audio.match.play()    
    gameDisplay.blit(lightFossil,[250,0])
    DialogBox.displayText("WOW! That is incredible! You had no",yellow,
    "idea! This is too good to be true!",yellow,
    "If only you knew about this before",yellow,
    "It could have been a total game changer!",yellow,False,False)
    gameDisplay.blit(matches,[460,90])
    DialogBox.displayText("This whole time, you had matches?! You",yellow,
    "could have been lighting things on fire!",yellow,
    "",yellow,
    "Oh, and there is a fossil on the wall. Neat.",yellow,False,False)
    DialogBox.displayText("Hey the the fire ring on your finger",yellow,
    "is drawing the flame to it. You move it",yellow,
    "closer and the fire from the match gets",yellow,
    "completely sucked up by the ring.",yellow,False,False)
    gameDisplay.blit(darkFossil,[250,0])
    audio.getItem1.play()
    audio.getItem2.play()
    DialogBox.displayText("                         New Boost:",yellow,
    "                     Fire + 15 damage",green,
    "                       Now available!",yellow,"",yellow,False,False)
    savables.fireMax += 15
    audio.match.play()
    gameDisplay.blit(lightFossil,[250,0])
    DialogBox.displayText("You light another match hoping to get",yellow,
    "the same effect. Nope, the ring's thirst",yellow,
    "appears to have been quenched. Time to",yellow,
    "move on. You continue down the corridor.",yellow,False,False)
    
HillaryPic = pygame.image.load('pictures\\rooms\\hillary.jpg')    
def Hillary():
    audio.doorSound.play()
    DialogBox.displayText("An ominous chant can be heard on the",yellow,
    "other side of this door...",yellow,"",yellow,"",yellow,False,False)
    gameDisplay.blit(HillaryPic,[250,0])
    audio.hillaryLaugh.play()
    DialogBox.displayText("Hmm, it looks like this room is occupied",yellow,
    "by somone communing with Satan. You",yellow,
    "decide not to interrupt and leave the",yellow,
    "she-deamon to her human sacrificing.",yellow,False,False)
    
    
    
    