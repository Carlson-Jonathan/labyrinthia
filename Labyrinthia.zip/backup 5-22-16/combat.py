import DialogBox,pygame,random,corridor1,randMonster,weapons,door,audio,savables,time
gameDisplay = pygame.display.set_mode((900,600))
green,yellow,orange = (0,225,0),(240,240,0),(255,155,0)
monsterHealth,attackDamage,monsterBar = 20,0,200
equip,battle = "none",False
NoWeaponSelected = True
red = (255,0,0)
clock = pygame.time.Clock()

def combat():
    global battle,monsterBar
    monsterBar = 200
    battle = True
    global monsterHealth,totalMhealth
    from randMonster import monsterStrength
    if monsterStrength == "weak":
        monsterHealth = random.randint(50,70)
    elif monsterStrength == "medium":
        monsterHealth = random.randint (150,250)
    elif monsterStrength == "strong":
        monsterHealth = random.randint (500,600)
    elif monsterStrength == "boss":
        monsterHealth = 1000
    totalMhealth = monsterHealth        
    fight()   
        
def combatOptions():        
    DialogBox.displayText("Your action?",yellow,
        "     Attack                       Use Item",green,
        "     Defend                      Change Weapon",green,
        "     Flee                           Inspect Monster",green,
        True, True)
    combatOptionSelection("newRound")


# defines which menu will apply to the selections choice
def combatOptionSelection(optionType):
    global equip,NoWeaponSelected
    choiceNum = (DialogBox.selectionx*DialogBox.selectiony)
    if choiceNum == 3:
        if NoWeaponSelected == True:
            weaponSelect() 
        elif optionType == "selectWeapon":
            equip = "fists"
            weapons.skillBar = 0
            combatOptions()
        elif optionType == "newRound":
            attack(equip)
    elif choiceNum == 4:
        if optionType == "newRound":
            monsterAttack(True)
        elif optionType == "selectWeapon":
            if "sword" in savables.weaponInventory:
                weapons.skillBar = savables.swordTick
                equip = "sword"
                audio.drawSword.play()
            else:
                DialogBox.displayText("That weapon is not available.",red,
                    "",yellow,"",yellow,"",yellow,False,False)
                weaponSelect()
            combatOptions()
    elif choiceNum == 5:
        if optionType == "newRound":
            choice = "flee"
        elif optionType == "selectWeapon":
            if "staff" in savables.weaponInventory:
                weapons.skillBar = savables.staffTick
                equip = "staff"
                weapons.swooshCombo(3)
            else:
                DialogBox.displayText("That weapon is not available.",red,
                    "",yellow,"",yellow,"",yellow,False,False)
                weaponSelect()
            combatOptions()
    elif choiceNum == 6:
        if optionType == "newRound":
            choice = "use an item"
        elif optionType == "selectWeapon":
            if "fire" in savables.weaponInventory:
                weapons.skillBar = savables.fireTick
                equip = "fire"
                audio.inferno.play()
            else:
                DialogBox.displayText("That weapon is not available.",red,
                    "",yellow,"",yellow,"",yellow,False,False)
                weaponSelect()
            combatOptions()
    elif choiceNum == 8:
        if optionType == "newRound":
            weaponSelect()
        elif optionType == "selectWeapon":
            if "ice" in savables.weaponInventory:
                weapons.skillBar = savables.iceTick
                equip = "ice"
            else:
                DialogBox.displayText("That weapon is not available.",red,
                    "",yellow,"",yellow,"",yellow,False,False)
                weaponSelect()
            combatOptions()
    elif choiceNum == 10:
        if optionType == "newRound":
            choice = "inspect the monster"
        elif optionType == "selectWeapon":
            if "gun" in savables.weaponInventory:
                weapons.skillBar = 0
                equip = "gun"
            else:
                DialogBox.displayText("That weapon is not available.",red,
                    "",yellow,"",yellow,"",yellow,False,False)
                weaponSelect()
            combatOptions()
            
def attack(weapon):
    global monsterHealth,attackDamage,monsterBar
    weapons.staff() if weapon == "staff" else ""
    weapons.fists() if weapon == "fists" else ""
    weapons.sword() if weapon == "sword" else ""
    weapons.fire() if weapon == "fire" else ""
    weapons.ice() if weapon == "ice" else ""
    monsterBar = (((monsterHealth*100)/totalMhealth)*2)
    monsterAttack(False)

def monsterAttack(defend):
    global battle,monsterHealth
    if monsterHealth <= 0:
        gameDisplay.blit(randMonster.monsterBackground,[250,0])
        DialogBox.displayText("The %s drops to the"%randMonster.monster,yellow,
            "ground writhing and squealing!",yellow,"You are victorious!",yellow,
            "",yellow,False,False)
        battle = False
        audio.pygame.mixer.music.fadeout(3000)
        
    else:
        global equip
        par = random.randint(1,3)
        monsterDamage = random.randint(5,15)
        monsterDamage = (monsterDamage/2) if defend == True else monsterDamage
        if equip == "sword" and par == 3 and DialogBox.skill >= 1:
            weapons.parry()
            rip = random.randint(1,2)
            if rip == 2 and DialogBox.skill >= 2:
                weapons.riposte()
        else:
            weapons.weaponAnimations = True
            audio.monsterAttackSound.play() # Need all monsters assigned first
            DialogBox.displayText("The %s attacks!"%randMonster.monster,yellow,
                "",orange,"",yellow,"",yellow,False,False)
            time.sleep(.4)#add sleep delays in randMonster to sync attack sound and shake
            takeDamageAnimation()
            weapons.weaponAnimations = False
            DialogBox.displayText("The %s attacks!"%randMonster.monster,yellow,
                "You take %d damage!"%monsterDamage,orange,"",yellow,"",yellow,False,False)
            additionalRoar()
            savables.health -= monsterDamage
        defend = False
        
def takeDamageAnimation():
    shakes,x,y = 0,250,0
    monsterLair = randMonster.monsterBackground
    monsterPic = randMonster.monsterPic        
    def compress():
        gameDisplay.blit(monsterLair,[x,y])
        weapons.redrawBorders()
        gameDisplay.blit(monsterPic,(250,0)) 
        pygame.display.update()
    while shakes < 6:
        clock.tick(50)
        x -= 5
        y -= 5   
        compress()
        x += 10
        y += 10
        compress()
        x -= 10
        compress()
        x += 10
        y -= 10
        compress()
        x -= 5
        y += 5
        compress()
        shakes += 1

roarRepitition = 1
def additionalRoar():
    global roarRepitition
    if roarRepitition%5 == 0:
        audio.monsterRoar.play()
    roarRepitition += 1
            
def weaponSelect():
    global NoWeaponSelected,equip

    fistFire = ("     Fists                          Fire")
    swordIce = ("     Sword                        Ice")
    staffGun = ("     Staff                         Mini Gun")
    fistOnly = ("     Fists                          ?")
    swordOnly = ("     Sword                        ?")
    staffOnly = ("     Staff                         ?")
    iceOnly = ("     ?                                Ice")
    gunOnly = ("     ?                                Mini Gun")
    noneRow2 = ("     ?                                ?")
    noneRow3 = ("     ?                                ?")
    
    # options row 1    
    if "fire" in savables.weaponInventory:
        row1 = fistFire
    else:
        row1 = fistOnly
    # options row 2
    if "sword" in savables.weaponInventory and "ice" in savables.weaponInventory:
        row2 = swordIce
    elif "sword" in savables.weaponInventory and "ice" not in savables.weaponInventory:
        row2 = swordOnly
    elif "sword" not in savables.weaponInventory and "ice" in savables.weaponInventory:
        row2 = iceOnly
    else:
        row2 = noneRow2
    # options row 3
    if "staff" in savables.weaponInventory and "gun" in savables.weaponInventory:
        row3 = staffGun
    elif "staff" in savables.weaponInventory and "gun" not in savables.weaponInventory:
        row3 = staffOnly
    elif "staff" not in savables.weaponInventory and "gun" in savables.weaponInventory:
        row3 = gunOnly
    else:
        row3 = noneRow3
        
    DialogBox.displayText("Select your weapon:",yellow,row1,orange,row2,orange,row3,orange,True,True)
    NoWeaponSelected = False      
    combatOptionSelection("selectWeapon")  

dispDamage = "0"
def damageDisplay():
    fistDamage = "4 - 12"
    swordDamage = "15 - 25"
    staffDamage = "10 - 20"
    fireDamage = "1 - 50"
    iceDamage = "20"
    gunDamage = "???"    
    global dispDamage
    if equip == "fists":
        dispDamage = fistDamage
    elif equip == "sword":
        dispDamage = swordDamage
    elif equip == "staff":
        dispDamage = staffDamage
    elif equip == "fire":
        dispDamage = fireDamage
    elif equip == "ice":
        dispDamage = iceDamage
    elif equip == "gun":
        dispDamage = gunDamage    

def fight():
    while battle == True:
        clock.tick(35)
        combatOptions()