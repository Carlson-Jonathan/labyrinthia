import pygame,sys,DialogBox,corridor1,combat,yell,door,startCavern,leprechaun,otherRooms2,randMonster
from pygame.locals import *

# basic variable definitions

white = (255,255,255)
red = (255,0,0)
green = (0,225,0)
darkgreen = (0,125,0)
black = (0,0,0)
blue = (0,0,75)
yellow = (240,240,0)
brown = (200,200,150)

# pygame initialization
pygame.init()
screen=pygame.display.set_mode((900,600),0,32)
pygame.display.set_caption('Labyrinthia')
gameDisplay = pygame.display.set_mode((900,600))
clock = pygame.time.Clock()
clock.tick(35)

font = pygame.font.SysFont("comicsansms",30)
combat.battle = False
logo = pygame.image.load('pictures\\logo.png')
keyControls = pygame.image.load('pictures\\arrowKeys.jpg')

# main game loop
def game_loop():
    startScreen = True
    while True:
        clock.tick(5)
        for event in pygame.event.get():
            
            # 'Quit' function
            def XQuit():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
            XQuit()
            
            # Title Screen
            while startScreen == True:
                XQuit()
                TitleScreen = pygame.image.load('pictures\TitleScreen.jpg')
                gameDisplay.blit(TitleScreen,(0,0)) 
                openCaption3 = font.render("Press [ENTER] to continue",True,brown,)
                gameDisplay.blit(openCaption3,[270,395])
                for event in pygame.event.get():
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_RETURN:# or pygame.K_KP_ENTER:
                            gameDisplay.fill(black)
                            startScreen = False
                pygame.display.update()
            
            # opening text
            gameDisplay.blit(logo,[300,150])
            DialogBox.displayText("              Welcome to Labyrinthia!",yellow,
            "                  by Jonathan Carlson",green,"",yellow,"",yellow,False,False)
            gameDisplay.fill(black)            
            gameDisplay.blit(keyControls,[300,100])
            DialogBox.displayText("          Use the ARROW keys and the",yellow,
                                "                 [ENTER] key to play.",yellow,"",yellow,"",yellow,False,False)
            DialogBox.displayText("This is a story about someone being",yellow,
                                   "lost in some kind of labyrinth dungeon.",yellow,
                                  "Your character must find a way out of the",yellow,
                                    "labyrinth without dying.",yellow,False,False)
            DialogBox.displayText("You will control the character using",yellow,
                        "the arrow keys and ENTER key.",yellow,
                        "Fight monsters, explore around, find clues,",yellow,
                        "& aquire weapons and special items to win.",yellow,False,False)
            
            import otherRooms,grate
            #otherRooms.gunRoom()
            #otherRooms.shrine()
            #corridor1.poolRoom()
            #otherRooms.bathroom()
            #otherRooms.potionsRoulette()
            #otherRooms.barney()
            #startCavern.startingCavern()
            #corridor1.snakePit()
            #corridor1.startText()
            #yell.yell2() #<-- get you to leprechaun
            #otherRooms2.fossil()
            #otherRooms2.Hillary()
            #corridor1.forkleft()
            #randMonster.randMonster("strong",4)
            #corridor1.findIceBridge()
            randMonster.randMonster("medium",3)

#start trigger
game_loop()

  