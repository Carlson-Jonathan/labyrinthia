
healthPotions = ["potion","potion","potion","potion"]
regenPotions = ["regenPotion","regenPotion"]
usableItems = []
healthTanks = 0
boosterInventory = []
# Potential items: 
    # Health Tank 1-x
    # leprecaller
    # save orb
    # 

health = 100 

weaponInventory = ["fire","staff","sword"]

swordMin,swordMax = 15,25
fireMin,fireMax = 1,50
iceDamage = 20
staffMin,staffMax = 10,20

fistSkill = 0
swordSkill = 0
staffSkill = 3
fireSkill = 3
iceSkill = 0
gunSkill = 0

swordTick = 0
staffTick = 0
fireTick = 0
iceTick = 0

# Menu and event non-repeatables:
#leprechaun:
allMenuItemsComplete = False
opt1 = False
opt6 = False

