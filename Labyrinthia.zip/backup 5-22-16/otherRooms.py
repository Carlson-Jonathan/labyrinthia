import pygame,DialogBox,audio,combat,savables,random
gameDisplay = pygame.display.set_mode((900,600))
yellow,green,orange,red = (240,240,0),(0,255,0),(255,155,0),(255,0,0)

'''
Module Contents:
    Armory  
    Shrine
    Bathroon
    Potion Roulette
    Barney
'''

# Armory - obtain minigun
armory = pygame.image.load('pictures\\rooms\\armory.jpg')
minigun = pygame.image.load('pictures\\weapons\\minigun.png')
def gunRoom():
    gameDisplay.blit(armory,[250,0])    
    DialogBox.displayText("Oh...",yellow,"",yellow,"",yellow,
    "",yellow,False,False)
    DialogBox.displayText("Oh...",yellow,"my...",yellow,"",yellow,
    "",yellow,False,False)
    audio.gunRoomLaugh.play()
    DialogBox.displayText("Oh...",yellow,"my...",yellow,
    "G O O D N E S S ! ! ! ! ! ! ! !",yellow,
    "",yellow,False,False)
    DialogBox.displayText("Words can't even begin to describe...",yellow,
    "You drooooool over all the goodies in",yellow,
    "this room. This is just tooooo good",yellow,
    "to be true!!!",yellow,False,False)
    DialogBox.displayText("Of all the options, all the ways",yellow,
    "to kill... If only you had some of this stuff",yellow,
    "earlier. You think your decision is going",yellow,
    "to be a tough one- but then you see it.",yellow,False,False)
    gameDisplay.blit(minigun,[410,50])
    DialogBox.displayText("Ooooooooohhh Yeeeeeeessssssss!!!",yellow,
    "",yellow,"",yellow,"",yellow,False,False)
    audio.getItem1.play()
    audio.getItem2.play()
    DialogBox.displayText("                        New Weapon:",yellow,
    "                        Widow Maker",green,
    "                        Now available!",yellow,"",yellow,False,False)
    savables.weaponInventory.append("gun")
    
# Shrine - obtain save orb
saveOrb = pygame.image.load('pictures\\items\\orb.png')
shrineRoom = pygame.image.load('pictures\\rooms\\shrine.jpg')
def shrine():
    gameDisplay.blit(shrineRoom,[250,0])
    DialogBox.displayText("What is this? A shrine of some sort. It",yellow,
    "looks like this was used at one point for",yellow,
    "ceremonial rituals. Looking around you ",yellow,
    "dont see anything useful, except for...",yellow,False,False)
    gameDisplay.blit(saveOrb,[470,70])    
    DialogBox.displayText("There, on the alter- what is that? You",yellow,
    "feel strangely drawn to it. As you reach out",yellow,
    "for the strange object you feel that some",yellow,
    "sort of divinity is watching over you.",yellow,False,False)
    audio.getItem1.play()
    audio.getItem2.play()
    DialogBox.displayText("                          New Item:",yellow,
    "                          Save Orb",green,
    "                        Now available!",yellow,"",yellow,False,False)
    savables.usableItems.append(saveOrb)

healthTank = pygame.image.load('pictures\\items\\healthTank.png')
bathroomPic = pygame.image.load('pictures\\rooms\\bathroom.jpg')   
def bathroom():
    audio.doorSound.play()
    DialogBox.displayText("The door opens with a creek. What",yellow,
    "unspeakable horror could be waiting for",yellow,
    "you on the other side of this door?",yellow,"",yellow,False,False)
    gameDisplay.blit(bathroomPic,[250,0])
    DialogBox.displayText("Yes! Finally! After drinking all those",yellow,
    "potions you seriously need to pee!!! You",yellow,
    "can also take a bath and wash your wounds.",yellow,
    "Let's see what is in the medicine cabinet.",yellow,False,False)
    gameDisplay.blit(healthTank,[410,70])
    DialogBox.displayText("Oh, you couldnt have found this at a",yellow,
    "better time! The monsters are getting.",yellow,
    "tough! Time for a powerup!",yellow,
    "",yellow,False,False) 
    audio.metriodAcquire.play()
    DialogBox.displayText("                         New Boost:",yellow,
    "                        Health Tank",green,
    "                          Acquired!",yellow,"",yellow,False,False)
    savables.healthTanks += 1
    savables.health += 100
    
# Potion Roulette ----------------------------
rouletteRoom = pygame.image.load('pictures\\rooms\\rouletteRoom.jpg')
def potionsRoulette():
    gameDisplay.blit(rouletteRoom,[250,0])
    DialogBox.displayText("You wander into a room that is empty",yellow,
    "except for a table in the middle with 6",yellow,
    "potions sitting on it. On the wall is a",yellow,
    "plack that reads,",yellow,False,False)
    roulettePlack()
    
def roulettePlack():
    DialogBox.displayText("'To those who enter in this room,",orange,
    "Drinking a mixture may cause doom,",orange,
    "Strength and health and wisdom await,",orange,
    "Adventurers who tempt their fate.'",orange,False,False)
    DialogBox.displayText("'Four give power, one gives breath,",orange,
    "Lastly, one will bring swift death,",orange,
    "For them who curb, there is no shame,",orange,
    "In fleeing from this deadly game.'",orange,False,False)
    DialogBox.displayText("Well, this is pretty self-explanatory.",yellow,
    "What do you say? Care to play a game",yellow,
    "of potion roulette?",yellow,"",yellow,False,False)
    rouletteOptions()

def rouletteOptions():
    DialogBox.displayText("What will you do?",yellow,
    "     Drink a potion",green,
    "     Read plack again",green,
    "     Leave room",green,True,True)
    actionSelection(rouletteOptions)
    
def actionSelection(priorMenu):
    threeChoiceMenu = [rouletteOptions]
    choiceNum = (DialogBox.selectionx*DialogBox.selectiony)
    if choiceNum == 3:
        drinkPotion()
    elif choiceNum == 4:
        roulettePlack()
    elif choiceNum == 5:
        leave()
    elif choiceNum == 6:
        invalid(priorMenu) if priorMenu in threeChoiceMenu else ""
    elif choiceNum == 8:
        invalid(priorMenu) if priorMenu in threeChoiceMenu else ""
    elif choiceNum == 10:
        openBarneyDoor() if priorMenu == barneyOptions1 else ""
        barneyAttack() if priorMenu == barneyOptions2 else ""
        invalid(priorMenu) if priorMenu in threeChoiceMenu else ""
    
def invalid(priorMenu):
    DialogBox.displayText("That is not a valid option. Try again.",red,
    "",yellow,"",yellow,"",yellow,False,False)
    priorMenu()
    
def drinkPotion():
    DialogBox.displayText("Which potion will you drink?",yellow,
    "     Red Potion                  Orange Potion",green,
    "     Yellow Potion              Green Potion",green,
    "     Blue Potion                 Purple Potion",green,True,True)
    downTheHatch()

redDrank,yellowDrank,greenDrank,orangeDrank,blueDrank,purpleDrank=False,False,False,False,False,False    
def downTheHatch():
    global redDrank,yellowDrank,greenDrank,orangeDrank,blueDrank,purpleDrank
    choiceNum = (DialogBox.selectionx*DialogBox.selectiony)
    if choiceNum == 3 and redDrank == False:
        redDrank = True
        DialogBox.displayText("Ahhh red! Can't go wrong with the color",yellow,
        "of blood and guts. You pop the cork and",yellow,
        "gulp it down...",yellow,"",yellow,False,False)
        potionResultGenerator()
    elif choiceNum == 4 and yellowDrank == False:
        yellowDrank = True
        DialogBox.displayText("Lemony yellow! Nothing poisonous has ever",yellow,
        "been colored yellow! This is a win for sure!",yellow,
        "You pop the cork and gulp it down...",yellow,
        "",yellow,False,False)
        potionResultGenerator()
    elif choiceNum == 5 and blueDrank == False:
        blueDrank = True
        DialogBox.displayText("Of course! Everyone's favorite color! The",yellow,
        "logic is infallable! You pop the cork and",yellow,
        "gulp it down...",yellow,"",yellow,False,False)
        potionResultGenerator()
    elif choiceNum == 6 and orangeDrank == False:
        orangeDrank = True
        DialogBox.displayText("Citrusy orange. If nothing else, this one",yellow,
        "should at least be loaded with vitamin C!",yellow, 
        "You pop the cork and gulp it down...",yellow,
        "",yellow,False,False)
        potionResultGenerator()
    elif choiceNum == 8 and greenDrank == False:
        greenDrank = True
        DialogBox.displayText("The color of money! This one looks like a",yellow,
        "payout! You pop the cork and gulp it down.",yellow,
        "",yellow,"",yellow,False,False)
        potionResultGenerator()
    elif choiceNum == 10 and purpleDrank == False:
        purpleDrank = True
        DialogBox.displayText("Thick and inky life-giving purple. Reminds,",yellow,
        "you of unicorns and fairies and...stuff.",yellow,
        "You pop the cork and gulp it down...",yellow,"",yellow,False,False)
        potionResultGenerator()
    else:
        DialogBox.displayText("You already drank that potion. Drink",yellow,
        "a different color.",yellow,"",yellow,"",yellow,False,False)
        drinkPotion()

effects = range(6)
potionEffects = [i for i in effects]
def potionResultGenerator():
    global potionEffects
    random.shuffle(potionEffects)
    poison() if potionEffects[0] == 0 else ""
    healthRestore() if potionEffects[0] == 2 else ""
    swordDamageUp() if potionEffects[0] == 3 else ""
    staffDamageUp() if potionEffects[0] == 4 else ""
    fireDamageUp() if potionEffects[0] == 5 else ""
    iceDamageUp() if potionEffects[0] == 1 else ""
    potionEffects.pop(0)
    rouletteOptions()
    
def poison():
    DialogBox.displayText("Poison",yellow,"",yellow,"",yellow,"",yellow,False,False)
    
def healthRestore():
    DialogBox.displayText("Restore Health",yellow,"",yellow,"",yellow,"",yellow,False,False)
    
def swordDamageUp():
    DialogBox.displayText("Sword +",yellow,"",yellow,"",yellow,"",yellow,False,False)
    
def staffDamageUp():
    DialogBox.displayText("Staff +",yellow,"",yellow,"",yellow,"",yellow,False,False)
    
def fireDamageUp():
    DialogBox.displayText("Fire +",yellow,"",yellow,"",yellow,"",yellow,False,False)
    
def iceDamageUp():
    DialogBox.displayText("Ice +",yellow,"",yellow,"",yellow,"",yellow,False,False)

# -------------------------------------------

barneyDoor = pygame.image.load('pictures\\rooms\\door.png')
def barney():
    gameDisplay.blit(barneyDoor,[250,0])
    DialogBox.displayText("You come to the end of the tunnel.",yellow,
    "Whatever is behind this door seems to be",yellow,
    "attacking your very soul. There is a",yellow,
    "hideously evil feeling lurking in the air.",yellow,False,False)
    audio.heartBeat.play()
    DialogBox.displayText("You reach for the door and your hand",yellow,
    "unexpectingly begins to bleed. You feel",yellow,
    "sick to your stomach. It's not too late",yellow,
    "to turn back...",yellow,False,False)
    barneyOptions1()
    
def barneyOptions1():
    DialogBox.displayText("What will you do?",yellow,
    "     Turn back                  Flee",green,
    "     Run Away                   Retreat",green,
    "     Escape                       Open door?",green,True,True)
    actionSelection(barneyOptions1)    
    
def openBarneyDoor():
    DialogBox.displayText("That is not a valid option. Try again.",red,
    "",yellow,"",yellow,"",yellow,False,False)
    DialogBox.displayText("That is not a valid option. Try again.",red,
    "Ok, I am lying, it is a valid option",yellow,
    "but are you sure you want to do this?",yellow,
    "",yellow,False,False)
    barneyOptions2()
    
def barneyOptions2():
    DialogBox.displayText("Open the door? Really?",yellow,
    "     No                             No",green,
    "     No                             No",green,
    "     No                             Not no",green,True,True)
    actionSelection(barneyOptions2)

barneyPic = pygame.image.load('pictures\\rooms\\barney.jpg')
def barneyAttack():
    audio.doorSound.play()
    DialogBox.displayText("The door creeks open...",yellow,
    "",yellow,"",yellow,"",yellow,False,False)
    gameDisplay.blit(barneyPic,[250,0])
    audio.scream.play()
    DialogBox.displayText("No. NOOOOOOOOOOOOOOOOOOO!!!",yellow,
    "AAAAAAAAAAAAAAAAAAAAAHHHH!!!",orange,
    "HELP ME HELP ME HELP ME HELP ME!",red,
    "      RUUUUUUUUUUUUUUN!!!!!!!!!!!!",yellow,False,False)
    DialogBox.displayText("'I love you, you love me...'",green,
    "",yellow,"",yellow,"",yellow,False,False)
    DialogBox.displayText("'I love you, you love me...'",green,
    "           20 damage!",orange,
    "",yellow,"",yellow,False,False)
    savables.health -= 20
    DialogBox.displayText("'I love you, you love me...'",green,
    "           20 damage!",orange,
    "                  32 damage!",orange,"",yellow,False,False)
    savables.health -= 32
    DialogBox.displayText("'I love you, you love me...'",green,
    "           20 damage!",orange,
    "                  32 damage!",orange,
    "                         44 damage!",orange,False,False)
    savables.health -= 44
    DialogBox.displayText("GET OUT NOW! RUN!!! RUUUUUN!!!",red,
    "",yellow,"",yellow,"",yellow,False,False)
    DialogBox.displayText("You bolt out the door in such a haste",yellow,
    "that you drop several items durring your",yellow,
    "retreat.",yellow,"",yellow,False,False)
    savables.healthPotions.pop(0)
    savables.healthPotions.pop(0)
    savables.healthPotions.pop(0)
    savables.regenPotions.pop(0)
    gameDisplay.blit(barneyDoor,[250,0])
    DialogBox.displayText("The door slams itself behind you and the",yellow,
    "door handle melts. Blood oozes from the",yellow,
    "cracks in and and around the door. It",yellow,
    "must never be opened again!",yellow,False,False )
    
     
    