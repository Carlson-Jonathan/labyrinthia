import random,DialogBox,pygame,randMonster,combat,door,grate,yell,audio,savables,weapons
green,yellow = (0,225,0),(240,240,0)
gameDisplay = pygame.display.set_mode((900,600))
orange = (255,155,0)
red = (255,0,0)
healthPotion = pygame.image.load('pictures\\items\\health_potion.png')

# User selection interpreter function
def travelOptions(travelType):
    fiveChoiceMenu = [start]
    fourChoiceMenu = []
    threeChoiceMenu = [iceBridge,fork,bats,iceBridge,pool,dragon,
    tunnelGrateOptions,snakePitOptions]
    choiceNum = (DialogBox.selectionx*DialogBox.selectiony)
    if choiceNum == 3:
        crossIceBridge() if travelType == iceBridge else ""
        dragonSneak() if travelType == dragon else ""
        poolDrink() if travelType == pool else ""
        door.door() if travelType == start else ""
        forkleft() if travelType == fork else ""
        batActionSneak() if travelType == bats else ""
        snakePitJump() if travelType == snakePitOptions else ""
        iceAnswerIncorrect() if travelType == iceQuestionAnswers1 or travelType == iceQuestionAnswers2 or travelType == iceQuestionAnswers3 else ""
    elif choiceNum == 4:
        iceAnswerIncorrect() if travelType == iceQuestionAnswers2 or travelType == iceQuestionAnswers3 else ""
        iceAnswerCorrect(1) if travelType == iceQuestionAnswers1 else ""
        snakePit() if travelType == fork else ""
        grate.grate() if travelType == tunnelGrateOptions else ""
        batActionRun() if travelType == bats else "" 
        snakePitTurn() if travelType == snakePitOptions else ""
    elif choiceNum == 5:
        iceDoorOpen() if travelType == iceQuestionAnswers3 else ""
        iceAnswerIncorrect() if travelType == iceQuestionAnswers1 or travelType == iceQuestionAnswers2 else ""
        batActionNoise() if travelType == bats else ""
        if travelType == snakePitOptions:
            snakePitPlay() if snakePlaytime == False else snakePitPlay2() 
        yell.yell() if travelType == tunnelGrateOptions or travelType == fork else ""
        roll = random.randint(1,5)
        if roll == 1:
            hallwayPotion()
        elif roll == 2:
            batTunnel()
        elif roll == 3:
            findIceBridge()
        elif roll == 4:
            poolRoom()
        elif roll == 5:
            corridorFork()
    elif choiceNum == 6:
        iceAnswerCorrect(2) if travelType == iceQuestionAnswers2 else ""
        iceAnswerIncorrect() if travelType == iceQuestionAnswers1 or travelType == iceQuestionAnswers3 else "" 
        yell.yell() if travelType == start else ""
        if travelType in threeChoiceMenu:
            invalid()
            travelType()
    elif choiceNum == 8:
        notCute() if travelType == iceQuestionAnswers3 else ""
        iceAnswerIncorrect() if travelType == iceQuestionAnswers1 or travelType == iceQuestionAnswers2 or travelType == iceQuestionAnswers3 else ""
        randMonster.randMonster("strong",4) if travelType == start else "" 
        if travelType in threeChoiceMenu or travelType in fourChoiceMenu:
            invalid()
            travelType()
    elif choiceNum == 10:
        iceAnswerIncorrect() if travelType == iceQuestionAnswers1 or travelType == iceQuestionAnswers2 or travelType == iceQuestionAnswers3 else ""
        if travelType in threeChoiceMenu or travelType in fourChoiceMenu or travelType in fiveChoiceMenu:
            invalid()
            travelType()

def startText():
    corridor1 = pygame.image.load('pictures\\rooms\\tunnel1.jpg')
    gameDisplay.blit(corridor1,(250,0))
    DialogBox.displayText("You see a long corridor in front of you.",yellow,
        "There is a door on the left wall and a",yellow,
        "ladder going up on the right wall behind",yellow,
        "you. What would you like to do?",yellow,False,False)
    start()
    
def start():
    DialogBox.displayText("What will you do? Make your selection:",yellow,
        "     Open the door           Yell for help",green,
        "     Climb the ladder        Monster",green,
        "     Go down corridor       ",green,True,True)
    travelOptions(start)    

def invalid():
    DialogBox.displayText("Invalid selection. Try again.",red,
        "",yellow,"",yellow,"",yellow,False,False)
        
def corridorFork():
    fork1 = pygame.image.load('pictures\\rooms\\tunnelFork.jpg')
    gameDisplay.blit(fork1,[250,0])
    DialogBox.displayText("The tunnel comes to a fork. To the",yellow,
    "left you can feel a warm breeze and see",yellow,
    "a faint light. The right tunnel looks",yellow,
    "dark and emits and strange odor.",yellow,False,False)
    fork()


def hallwayPotion():
    gameDisplay.blit(healthPotion,[440,80])    
    DialogBox.displayText("                       *Ooof!*",orange,
    "You trip over something and fall.",yellow,
    "Whats this? It seems you have tripped",yellow,
    "over a magic potion!",yellow,False,False)
    savables.healthPotions.append("potion")
    DialogBox.displayText("Since there is nowhere else to go",yellow,
    "you continue walking down the corridor.",yellow,"",yellow,""
    ,yellow,False,False)
    start()

def forkleft():
    lightTunnel = pygame.image.load('pictures\\rooms\\lighttunnel.jpg')
    gameDisplay.blit(lightTunnel,[250,0])
    DialogBox.displayText("The light grows brighter and the air",yellow,
        "gets warmer the farther down the cooridor",yellow,
        "you get. Something just dosen't feel right.",yellow,"",yellow,False,False)
    dragon1 = pygame.image.load('pictures\\rooms\\sleepingdragon.jpg')
    gameDisplay.blit(dragon1,[250,0])
    DialogBox.displayText("You found the way out! But there is a",yellow,
        "sleeping dragon blocking the exit. If you",yellow,
        "are extremely careful, you might be able",yellow,
        "to sneak past it. It looks very risky!",yellow,False,False)
    dragon()
    
# --------------- Bats Events ----------------
def batActionRun():
    #global health
    roll = random.randint(1,2)
    DialogBox.displayText("You dash forward hoping to pass",yellow,
        "through the danger before any of those",yellow,
        "flying rodents can respond...",yellow,"",yellow,False,False)
    if roll == 1:
        damage = random.randint(7,12)
        DialogBox.displayText("After only a few steps you slip on",yellow,
        "bat guano and fall hard hitting your",yellow,
        "head on a rock.",yellow, 
        "You take %d damage!"%damage,orange,False,False)
        savables.health -= damage
        roll = random.randint(1,2)
        if roll == 1:
            DialogBox.displayText("As you get up you find the bats",yellow,
            "are still undisturbed. You make it safely",yellow,
            "through the danger.",yellow,"",yellow,False,False)
        if roll == 2:
            DialogBox.displayText("You stand up in the middle of a bat swarm!",yellow,
            "They have been whipped up into a frenzy",yellow,
            "by the disturbance you caused!",yellow,"",yellow,False,False)
            randMonster.randMonster("weak",4)
            batVictory()
    elif roll == 2:
        DialogBox.displayText("The bats suddenly drop from the ceiling",yellow,
        "and begin to swarm around you. A moment",yellow,
        "later, the cloud breaks and you see a",yellow,
        "a giagantic bat dive straight at you.",yellow,False,False)
        randMonster.randMonster("weak",4)
        batVictory()
        
def batActionSneak():
    DialogBox.displayText("You keep low and creep as quietly",yellow,
    "as you can passed the hanging flock.",yellow,"",yellow,"",yellow,False,False)
    DialogBox.displayText("You keep low and creep as quietly",yellow,
    "as you can passed the hanging flock.",yellow,
    "None of them have appeared to have",yellow,"been disturbed.",yellow,False,False)
    start()

def batActionNoise():
    DialogBox.displayText("It will be just like running",yellow,
    "through a flock of birds",yellow,
    "on the ground...",yellow,"",yellow,False,False)
    DialogBox.displayText("It will be just like running",yellow,
    "through a flock of birds",yellow,
    "on the ground...",yellow,"...right?",yellow,False,False)
    DialogBox.displayText("The bats suddenly drop from the ceiling",yellow,
    "and begin to swarm around you. A moment",yellow,
    "later, the cloud breaks and you see a",yellow,
    "a giagantic bat dive straight at you.",yellow,False,False)
    randMonster.randMonster("weak",4)
    batVictory()

def batTunnel():
    batCave = pygame.image.load('pictures\\rooms\\bats.jpg')
    gameDisplay.blit(batCave,[250,0])
    DialogBox.displayText("You make your way down the corridor",yellow,
    "only to discover a tunnel full of bats.",yellow,"",yellow,"",yellow,False,False)
    bats()
    
def bats():
    DialogBox.displayText("What will you do?",yellow,
    "     Try to sneak past",green,
    "     Run through them",green,
    "     Make lots of noise",green,True,True)
    travelOptions(bats)
    
def batVictory():
    import leprechaun
    DialogBox.displayText("With their leader defeated the rest of",yellow,
    "the bat swarm disapates.",yellow,"",yellow,"",yellow,False,False) 
    if "staff" not in savables.weaponInventory:
        DialogBox.displayText("Before continuing, you look up and",yellow,
        "notice many bats were hanging on a",yellow,
        "sturdy wooden staff stuck to the ceiling.",yellow,
        "",yellow,False,False)
        staffObtain = pygame.image.load('pictures\\weapons\\boStaff.png')
        gameDisplay.blit(staffObtain,[425,60])
        DialogBox.displayText("This looks like it would be a great weapon!",yellow,
        "You decide to grab it and free it from",yellow,
        "where it was lodged between the rocks.",yellow,"",yellow,False,False)
        audio.getItem1.play()
        audio.getItem2.play()
        DialogBox.displayText("                       New Weapon:",yellow,
        "                      Quarter Staff",green,
        "                       Now available!",yellow,"",yellow,False,False)
        savables.weaponInventory.append("staff")
    tunnelGrate()
# ---------------------------------    
    
def dragon():
    DialogBox.displayText("What will you attempt?",yellow,
    "     Sneak past",green,
    "     Make noise",green,
    "     Turn back",green,True,True)
    travelOptions(dragon)

dragonFace = pygame.image.load('pictures\\rooms\\dragonFace.jpg')
solidBlack = pygame.image.load('pictures\\rooms\\solidBlack.jpg')
def dragonSneak():
    DialogBox.displayText("The dragon is snoring flames from its",yellow,
    "snout. It is all you can do you remain quiet",yellow,
    "and creep around the beast without",yellow,
    "getting singed by its firey breath.",yellow,False,False)
    DialogBox.displayText("You made it! You can see the light",yellow,
    "of day within your reach! Then a burning",yellow,
    "wind can be felt from behind you. You",yellow,
    "turn around to see firey yellow eyes...",yellow,False,False)
    gameDisplay.blit(solidBlack,[250,0])
    audio.growling.play()
    clock = pygame.time.Clock()
    x = 550
    while x > 230:
        gameDisplay.blit(dragonFace,[x,0])
        weapons.redrawBorders()
        clock.tick(50)
        x -= 2
        pygame.display.update()
    DialogBox.displayText("The tunnel entrance is at least 200 feet",yellow,
    "away. There is nothing to hide behind and",yellow,
    "no way back. Oddly, a calm feeling sweeps ",yellow,
    "over with assurance that this is the end.",yellow,False,False)

def fork():
    DialogBox.displayText("What will you do?",yellow,
    "     Go left",green,
    "     Go right",green,
    "     Yell for help",green,True,True)
    travelOptions(fork)    

def findIceBridge():
    iceBridge1 = pygame.image.load('pictures\\rooms\\iceBridge.jpg')
    gameDisplay.blit(iceBridge1,[250,0])
    DialogBox.displayText("The temperature drops the longer you",yellow,
    "walk. You eventually come to a frozen",yellow,
    "tunnel with a bridge made entirely of ice!",yellow,
    "Crossing looks rather dangerous.",yellow,False,False)
    iceBridge()
    
def iceBridge():
    DialogBox.displayText("What will you do?",yellow,
    "     Try to cross",green,
    "     Look Down",green,
    "     Turn Back",green,True,True)
    travelOptions(iceBridge)
    
def crossIceBridge():
    DialogBox.displayText("What you wouldnt give for a nice pair",yellow,
    "of golf shoes right now! The bridge is",yellow,
    "as slick as can be and one stumble could",yellow,
    "spell doom. You carefully tread across.",yellow,False,False)
    roll = random.randint(1,2)
    if roll == 1:
        iceDoorRiddles()
    else:
        iceBridgeSlip()
        
def iceBridgeSlip():
    DialogBox.displayText("You make it to the center of the bridge",yellow,
    "but find it impossible to keep your footing.",yellow,
    "There is too much slope! You slide to the",yellow,
    "edge and tumble down into the abyss...",yellow,False,False)
    
def iceDoorRiddles():
    iceDoor = pygame.image.load('pictures\\rooms\\iceDoor.jpg')
    gameDisplay.blit(iceDoor,[250,0])
    DialogBox.displayText("You made it safely to the other side!",yellow,
    "Standing before you is a door encompassed",yellow,
    "in a glowing wall of ice. There is",yellow,
    "something inscribed in the ice...",yellow,False,False)
    DialogBox.displayText("As you read the engraving you hear",yellow,
    "a voice in your head as if the words",yellow,
    "are being spoken aloud. It says,",yellow,"",yellow,False,False)
    DialogBox.displayText("'This door shall remain sealed until", green,
    "three questions are answered correctly.",green,
    "An incorrect answer will expell you from",green,
    "this place. The first question is...'",green,False,False)
    DialogBox.displayText("'You are participating in a race.",green,
    "You overtake the second person. What",green,
    "position are you in? Give me your answer.'",green,"",yellow,False,False)
    iceQuestionAnswers1() 
    

def iceQuestion2():
    DialogBox.displayText("'What is the sum of the following:",green,
    "Take 1000 and add 40 to it.",green,
    "Add another 1000.",green,
    "Add 30.'",green,False,False)
    DialogBox.displayText("'Add another 1000.",green,
    "Now add 20.",green,
    "Add another 1000.",green,
    "Now add 10.'",green,False,False)
    iceQuestionAnswers2()  
    
def iceQuestion3():
    DialogBox.displayText("'Mary's father has five daughters...'",green,
    "",yellow,"",yellow,"",yellow,False,False)
    DialogBox.displayText("1. Nana",green,
    "2. Nene",green,
    "3. Nini",green,
    "4. Nono",green,False,False)
    DialogBox.displayText("'What is the name of the fifth daughter?'",green,
    "",yellow,"",yellow,"",yellow,False,False)
    iceQuestionAnswers3()
    
def iceAnswerCorrect(question):
    DialogBox.displayText("'That is correct.",green,
    "Here is your next question...'",green,
    "",yellow,"",yellow,False,False)
    iceQuestion2() if question == 1 else ""
    iceQuestion3() if question == 2 else ""
     
def iceAnswerIncorrect():
    DialogBox.displayText("'INCORRECT!'",red,
    "",yellow,"",yellow,"",yellow,False,False)
    DialogBox.displayText("'INCORRECT!'",red,
    "You suddenly feel a tremedous gush of",yellow,
    "wind push you back. You slide across the",yellow,
    "ice and fall into the gulf at the bridge.",yellow,False,False)
        
def iceQuestionAnswers1():
    DialogBox.displayText("How will you respond?",yellow,
    "     First Place                 Raspberry Jam",green,
    "     Second Place              I hate running",green,
    "     Third Place                Open the Door!!!",green,True,True)
    travelOptions(iceQuestionAnswers1)
    
def iceQuestionAnswers2():
    DialogBox.displayText("How will you resond?",yellow,
    "     5000                          4100",green,           
    "     4000                          I can't count",green,    
    "     5100                          Open Sesame?",green,True,True)
    travelOptions(iceQuestionAnswers2)
    
def iceQuestionAnswers3():
    DialogBox.displayText("How will you respond?",yellow,
    "     Nummy                      Nunu",green,
    "     Jane                          Is she cute?",green, 
    "     Mary                         I hate you!",green,True,True)
    travelOptions(iceQuestionAnswers3)
    
def notCute():
    DialogBox.displayText("No. Now what is your answer?",green,
    "",yellow,"",yellow,"",yellow,False,False)
    iceQuestionAnswers3()

iceWall = pygame.image.load('pictures\\rooms\\iceWall.jpg')
iceAmulet = pygame.image.load('pictures\\weapons\\iceAmulet.png')

def iceDoorOpen():
    audio.doorSound.play()
    DialogBox.displayText("'That is correct.'",green,
    "The giagantic door in the ice creeks open...",yellow,
    "",yellow,"",yellow,False,False)
    gameDisplay.blit(iceWall,[250,0])
    gameDisplay.blit(iceAmulet,[500,50])
    DialogBox.displayText("You expected to see another tunnel",yellow,
    "but the doors were actually a vault. There",yellow,
    "is a shining amulet hanging on the wall",yellow,
    "in the back of the vault.",yellow,False,False)
    DialogBox.displayText("You remove it and place it around your",yellow,
    "neck. It emits a soft blue glow. You are",yellow,
    "now able to shoot bolts of ice from your",yellow,
    "finger tips! Hooray for ice powers!",yellow,False,False)
    audio.getItem1.play()
    audio.getItem2.play()
    DialogBox.displayText("                       New Weapon:",yellow,
    "                         Ice Amulet",green,
    "                       Now available!",yellow,
    "",yellow,False,False)
    savables.weaponInventory.append("ice")
    
def poolRoom():
    pool1 = pygame.image.load('pictures\\rooms\\cavePool.jpg')
    gameDisplay.blit(pool1,[250,0])
    DialogBox.displayText("The corridor ends at a glowing pool of",yellow,
    "water. The water looks clear and clean.",yellow,
    "You feel like you could use a drink.",yellow,"",yellow,False,False)
    pool()
    
def pool():
    DialogBox.displayText("What will you do?",yellow,
    "     Drink from pool         Fill a bottle",green,
    "     Throw a rock in",green,
    "     Walk away",green,True, True)
    travelOptions(pool)

regenPotion = pygame.image.load('pictures\\items\\whitePotion.png')    
def poolDrink():
    DialogBox.displayText("You gracefully stroll up to the shimmering",yellow,
    "crystal water so as not to offend whatever",yellow,
    "generous spirits placed it here for you...",yellow,
    "",yellow,False,False)
    audio.splash.play()
    DialogBox.displayText("You gracefully stroll up to the shimmering",yellow,
    "crystal water so as not to offend whatever",yellow,
    "generous spirits placed it here for you...",yellow,
    "...and awkwardly plunk your head in.",yellow,False,False)
    DialogBox.displayText("The water tastes unbelievable! You have",yellow,
    "never tasted anything like it! This will",yellow,
    "surely give you a massive health boost!",yellow,
    "Let's see what it does...",yellow,False,False)
    savables.health += 5
    DialogBox.displayText("Um ok, +5 health is not a massive",yellow,
    "boost but per say but...",yellow,"",yellow,"",yellow,False,False)
    savables.health += 7 
    DialogBox.displayText("...and there is another +7 health.",yellow,
    "What in the world is this water...",yellow,"",yellow,"",yellow,False,False)
    savables.health += 4
    DialogBox.displayText("...+4 more health. Hmm, this water",yellow,
    "appears to have regenerative properties.",yellow,
    "After some time you feel your health",yellow,
    "fully recover before the effects wear off.",yellow,False,False)
    savables.health = DialogBox.maxHealth
    DialogBox.displayText("You have got to get a bottle of this stuff",yellow,
    "to go! Unfortunately you couldn't resist",yellow,
    "the overwhelming urge to smash every",yellow,
    "potion bottle you drank from.",yellow,False,False)
    gameDisplay.blit(regenPotion,[500,90])
    DialogBox.displayText("Hey look! There is a perfectly good",yellow,
    "bottle sitting over there in the corner!",yellow,
    "After filling it, you decide that this",yellow,
    "stuff should be saved for a fight.",yellow,False,False)
    savables.regenPotions.append("regenPotion")
    
def tunnelGrate():
    tunnelGratePic = pygame.image.load('pictures\\rooms\\tunnelGrate.jpg')
    gameDisplay.blit(tunnelGratePic,[250,0])
    DialogBox.displayText("You arrive at another corridor",yellow,
    "this one having a metal grate in the",yellow,
    "floor that easily comes off. There is",yellow,
    "a ladder going down the opening.",yellow,False,False)
    tunnelGrateOptions()
    
def tunnelGrateOptions():
    DialogBox.displayText("What will you do?",yellow,
    "     Go down corridor",green,
    "     Go down grate",green,
    "     Yell for help",green,True,True)
    travelOptions(tunnelGrateOptions)
    

# Snake Pit --------------------------
snakePitPic = pygame.image.load('pictures\\rooms\\snakePit.jpg')
def snakePit():
    DialogBox.displayText("The corridor continues but there is",yellow,
    "something blocking your path- sort of.",yellow,"",yellow,"",yellow,
    False,False)
    gameDisplay.blit(snakePitPic,[250,0])
    DialogBox.displayText("You look down and see a pit full of",yellow,
    "poisonous serpents. They look mean and!",yellow, 
    "very dangerous! The other side is not far.",yellow, 
    "in fact, you think you can jump across.",yellow,False,False)
    snakePitOptions()

def snakePitOptions(): 
    DialogBox.displayText("What will you do?",yellow,
    "     Jump over the pit",green,
    "     Turn back",green,
    "     Play with snakes",green,True,True)
    travelOptions(snakePitOptions)
    
def snakePitJump():
    DialogBox.displayText("You back up and get a running start then",yellow,
    "leap over the snake pit. That was easy.",yellow,
    "There isn't anywhere else to go but down",yellow,
    "the corridor. You continue walking.",yellow,False,False)
    
def snakePitTurn():
    DialogBox.displayText("You have seen the movies. As soon as you",yellow,
    "try to leap over the pit you would slip",yellow,
    "and fall in or something else stupid",yellow,
    "would happen. You decide to turn back...",yellow,False,False)
    DialogBox.displayText("...only to find that mommy has returned",yellow,
    "to the nest!",yellow,"Oh crap.",yellow,"",yellow,False,False)
    randMonster.randMonster("medium",4)
    snakePitVictory() if "healthTank1" not in savables.boosterInventory else ""
    
healthTank = pygame.image.load('pictures\\items\\healthTank.png')
def snakePitVictory():
    DialogBox.displayText("The giant anaconda hits the ground with a",yellow,
    "'thump'. Booya! Take that snakey boy!",yellow,
    "You notice a large lump rising up its.",yellow,
    "belly. It must have eaten something.",yellow,False,False)
    gameDisplay.blit(healthTank,[410,70])    
    DialogBox.displayText("The anaconda regurgitates a large tank",yellow,
    "of some sort. Slimey or not, you find it a",yellow,
    "good idea to take it along with you. Hmm,",yellow,
    "this odd tank makes you feel stronger!",yellow,False,False)
    audio.metriodAcquire.play()
    DialogBox.displayText("                         New Boost:",yellow,
    "                        Health Tank",green,
    "                          Acquired!",yellow,"",yellow,False,False)
    savables.healthTanks += 1
    savables.health += 100

snakePlaytime = False
def snakePitPlay():
    global snakePlaytime
    snakePlaytime = True
    DialogBox.displayText("You are way higher than they can reach.",yellow,
    "Why not have a little fun? What could",yellow,
    "possibly go wrong?",yellow,"",yellow,False,False)
    DialogBox.displayText("You pick up a few rocks and throw them",yellow,
    "down at the snakes. The snakes hiss loudly",yellow,
    "and stir around. What great fun! You grab",yellow,
    "another rock but realize, it's not a rock...",yellow,False,False)
    gameDisplay.blit(healthPotion,[440,80])
    DialogBox.displayText("It's a potion! Sweet! Well things are just",yellow,
    "as you thought. There is no harm at all in",yellow,
    "playing with deadly, poisonous creatures",yellow,
    "in dark, scary dungeons.",yellow,False,False)
    savables.healthPotions.append("potion")
    gameDisplay.blit(snakePitPic,[250,0])
    snakePitOptions()
    
def snakePitPlay2():
    DialogBox.displayText("Meh, you have already had your fun with",yellow,
    "these things. Besides, there dosent seem",yellow,
    "to be any more potions laying around.",yellow,
    "Do something else.",yellow,False,False)
    snakePitOptions()
    
    
# -----------------------------------