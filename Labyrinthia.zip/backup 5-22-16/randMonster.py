import random,pygame,DialogBox,combat,audio
clock = pygame.time.Clock()
gameDisplay = pygame.display.set_mode((900,600))
green,yellow = (0,225,0),(240,240,0)

monsterPic,monsterRoar,monster,attackSound,monsterStrength,monsterBackground = 0,0,"",0,0,0

def randMonster(strength,dice):
    global monsterStrength
    monsterStrength = strength
    if dice == "random":
        roll = random.randint(1,5)
    else:
        roll = dice
    if strength == "weak":
        weakMonsters(roll)
    elif strength == "medium":
        mediumMonsters(roll)
    elif strength == "strong":
        strongMonsters(roll)
    if strength == "weak" or strength == "medium":
        audio.pygame.mixer.music.load('Audio/battle.ogg')
    elif strength == "strong":
        audio.pygame.mixer.music.load('Audio/bossBattle.ogg')
    audio.monsterRoar.play() #need to assign to all monsters first
    audio.pygame.mixer.music.play(-1)
    encounterAnimation()
    DialogBox.displayText("A %s suddenly attacks!"%monster,yellow,
            "",yellow,"",yellow,"",yellow,False,False)
    combat.combat()
    
zoomX,zoomY = 0,0
blitX,blitY = 575,200
def encounterAnimation():
    global zoomX,zoomY,blitX,blitY
    while zoomX < 640:
        clock.tick(80)
        zoomX += 34
        zoomY += 20
        blitX -= 17
        blitY -= 10
        zoom = pygame.transform.scale(monsterPic,[zoomX,zoomY])
        zoom2 = pygame.transform.scale(monsterBackground,[zoomX,zoomY])
        gameDisplay.blit(zoom2,(blitX,blitY))
        gameDisplay.blit(zoom,(blitX,blitY))
        pygame.display.update()
    gameDisplay.blit(monsterBackground,[250,0])
    gameDisplay.blit(monsterPic,[250,0])
    zoomX,zoomY = 0,0
    blitX,blitY = 575,200
    
def weakMonsters(roll):
    global monster,monsterPic,monsterBackground
    if roll == 1:
        monsterPic = pygame.image.load('pictures\\monsters\\moleRat.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\ratTunnel.jpg')
        monster = "Gnaked Gnawer"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/rat.ogg')
        audio.monsterRoar.set_volume(.15)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/bite.ogg')
        audio.monsterAttackSound.set_volume(.15)
    elif roll == 2:
        monsterPic = pygame.image.load('pictures\\monsters\\terantula.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\scorpionTunnel.jpg')
        monster = "Acromantula"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/spiderRoar.ogg')
        audio.monsterRoar.set_volume(.3)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/spiderAttack.ogg')
        audio.monsterAttackSound.set_volume(.4)
    elif roll == 3:
        monsterPic = pygame.image.load('pictures\\monsters\\slime.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\slimeTunnel.jpg')
        monster = "Demon Slime" 
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/slimeRoar.ogg')
        audio.monsterRoar.set_volume(.4)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/slimeAttack.ogg')
        audio.monsterAttackSound.set_volume(.30)
    elif roll == 4:
        monsterPic = pygame.image.load('pictures\\monsters\\batKing.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\batRoom.jpg')
        monster = "Bat King"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/bats.ogg')
        audio.monsterRoar.set_volume(.15)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/batAttack.ogg')
        audio.monsterAttackSound.set_volume(.5)
    elif roll == 5:
        monsterPic = pygame.image.load('pictures\\monsters\\mantis.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\mantisTunnel.jpg')
        monster = "Killer Mantis"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/mantisRoar.ogg')
        audio.monsterRoar.set_volume(.3)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/goblinAttack.ogg')
        audio.monsterAttackSound.set_volume(.5)
        
def mediumMonsters(roll):
    global monster,monsterPic,monsterBackground        
    if roll == 1: 
        monsterPic = pygame.image.load('pictures\\monsters\\minitaur.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\minitaurArena.jpg')
        monster = "Minotaur"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/minataurRoar.ogg')
        audio.monsterRoar.set_volume(.3)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/minitaurAttack.ogg')
        audio.monsterAttackSound.set_volume(.6)
    elif roll == 2:
        monsterPic = pygame.image.load('pictures\\monsters\\goblin.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\goblinTunnel.jpg')
        monster = "Sinister Goblin"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/goblinRoar.ogg')
        audio.monsterRoar.set_volume(.3)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/goblinAttack.ogg')
        audio.monsterAttackSound.set_volume(.5)
    elif roll == 3:
        monsterPic = pygame.image.load('pictures\\monsters\\scorpion.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\scorpionTunnel.jpg')
        monster = "Seismic Scorpion"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/scorpionRoar.ogg')
        audio.monsterRoar.set_volume(.15)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/scorpionAttack.ogg')
        audio.monsterAttackSound.set_volume(.2)
    elif roll == 4:
        monsterPic = pygame.image.load('pictures\\monsters\\snake.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\snakeTunnel.jpg')
        monster = "Venomous Anaconda"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/snakeRoar.ogg')
        audio.monsterRoar.set_volume(.3)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/snakehit.ogg')
        audio.monsterAttackSound.set_volume(.2)
    elif roll == 5:
        monsterPic = pygame.image.load('pictures\\monsters\\trog.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\trogTunnel.jpg')
        monster = "Troglodtye Sentry"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/creatureLaugh.ogg')
        audio.monsterRoar.set_volume(.3)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/trogAttack.ogg')
        audio.monsterAttackSound.set_volume(.2)
        
def strongMonsters(roll):
    global monster,monsterPic,monsterBackground
    if roll == 1:
        monsterPic = pygame.image.load('pictures\\monsters\\dementor.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\ratWay.jpg')
        monster = "Guardian Shade"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/ghostRoar.ogg')
        audio.monsterRoar.set_volume(.3)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/ghostAttack.ogg')
        audio.monsterAttackSound.set_volume(.2)
    elif roll == 2:
        monsterPic = pygame.image.load('pictures\\monsters\\troll.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\trollCave.jpg')
        monster = "Collosal Troll"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/trollRoar.ogg')
        audio.monsterRoar.set_volume(.1)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/minitaurAttack.ogg')
        audio.monsterAttackSound.set_volume(.6)
    elif roll == 3:
        monsterPic = pygame.image.load('pictures\\monsters\\dog.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\dogTunnel.jpg')
        monster = "Cerberus"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/dogRoar.ogg')
        audio.monsterRoar.set_volume(.4)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/dogAttack.ogg')
        audio.monsterAttackSound.set_volume(.2)
    elif roll == 4:
        monsterPic = pygame.image.load('pictures\\monsters\\balrog.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\balrogBackground.jpg')
        monster = "Giga-Demon"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/roar.ogg')
        audio.monsterRoar.set_volume(.3)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/whipAttack.ogg')
        audio.monsterAttackSound.set_volume(.3)
    elif roll == 5:
        monsterPic = pygame.image.load('pictures\\monsters\\earthElemental.png')
        monsterBackground = pygame.image.load('pictures\\monsters\\elementalRoom.jpg')
        monster = "Earth Elemental"
        audio.monsterRoar = pygame.mixer.Sound('audio/monsters/elemental.ogg')
        audio.monsterRoar.set_volume(.4)
        audio.monsterAttackSound = pygame.mixer.Sound('audio/monsters/elementalAttack.ogg')
        audio.monsterAttackSound.set_volume(.7)
        
        
        