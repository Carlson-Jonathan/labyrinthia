import pygame

pygame.mixer.pre_init(44100, -16, 1, 512) #<-- fixes sound lag delay :D
pygame.init()

music = ('Audio/battle.ogg')
bossBattleMusic = ('Audio/bossBattle.ogg')
finalBattleMusic = ('Audio/finalBattle.ogg')
pygame.mixer.music.set_volume(.2)

drawSword = pygame.mixer.Sound('Audio/swordDraw.ogg')
drawSword.set_volume(.3)

inferno = pygame.mixer.Sound('Audio/fireDoorExplosion.ogg')
inferno.set_volume(.15)

fireBurn = pygame.mixer.Sound('Audio/fire.ogg')
fireBurn.set_volume(.2)

getItem1 = pygame.mixer.Sound('Audio/getItem1.ogg')
getItem1.set_volume(.2)
getItem2 = pygame.mixer.Sound('Audio/getItem2.ogg')
getItem2.set_volume(.2)

splash = pygame.mixer.Sound('Audio/splash.ogg')
splash.set_volume(.2)

weaponSwoosh = pygame.mixer.Sound('Audio/weaponSwoosh.ogg')
weaponSwoosh.set_volume(.3)

punch = pygame.mixer.Sound('Audio/punch.ogg')
punch.set_volume(.2)

monsterHit = pygame.mixer.Sound('Audio/strike2.ogg')
monsterHit.set_volume(.2)

parryAttack = pygame.mixer.Sound('Audio/swordecho.ogg')
parryAttack.set_volume(.1)

gunRoomLaugh = pygame.mixer.Sound('Audio/gunRoomLaugh.ogg')
gunRoomLaugh.set_volume(.2)

metriodAcquire = pygame.mixer.Sound('Audio/itemAcquasition.ogg')
metriodAcquire.set_volume(.6)

levelUp = pygame.mixer.Sound('Audio/levelup.ogg')
levelUp.set_volume(.2)

doorSound = pygame.mixer.Sound('Audio/door_2.ogg')
doorSound.set_volume(.2)

arrowTick = pygame.mixer.Sound("audio/tick.ogg")
arrowTick.set_volume(.2)

selectTick = pygame.mixer.Sound("audio/select.ogg")
selectTick.set_volume(.2)

textForward = pygame.mixer.Sound('audio/textForward.ogg')
textForward.set_volume(.2)

heartBeat = pygame.mixer.Sound('Audio/Hearbeat.ogg')
heartBeat.set_volume(.7)

scream = pygame.mixer.Sound('audio/scream.ogg')
scream.set_volume(.5)

match = pygame.mixer.Sound('audio/match.ogg')
match.set_volume(.4)

hillaryLaugh = pygame.mixer.Sound('audio/Hillary2.ogg')
hillaryLaugh.set_volume(.2)

growling = pygame.mixer.Sound('audio/monsters/growling.ogg')
growling.set_volume(.5)

monsterAttackSound = pygame.mixer.Sound('audio/monsters/whipAttack.ogg')
monsterRoar = pygame.mixer.Sound('audio/monsters/roar.ogg')

ouch = pygame.mixer.Sound('audio/whack.ogg')
ouch.set_volume(.2)
